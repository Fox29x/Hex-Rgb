Hex = input('Enter hex: ').lstrip('#')
print('RGB =', tuple(int(Hex[i:i+2], 16) for i in (0, 2, 4)))